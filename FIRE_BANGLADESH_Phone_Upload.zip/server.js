const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const PORT = process.env.PORT || 3000;
const publicDir = __dirname;
const server = http.createServer((req, res) => {
  const file = req.url === "/" ? "index.html" : req.url.replace(/^\/+/, "");
  const full = path.join(publicDir, file);
  if (!full.startsWith(publicDir)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(full);
    res.writeHead(200, { "Content-Type": ext === ".html" ? "text/html; charset=utf-8" : "text/plain" });
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });
const players = new Map();
const rooms = new Map();

function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function snapshot(room) {
  return [...players.values()].filter(p => p.room === room).map(({id,name,x,y,hp,color}) => ({id,name,x,y,hp,color}));
}
function broadcastRoom(room) {
  const msg = JSON.stringify({type:"state", players:snapshot(room)});
  for (const p of players.values()) if (p.room === room && p.ws.readyState === WebSocket.OPEN) p.ws.send(msg);
}
wss.on("connection", ws => {
  const id = Math.random().toString(36).slice(2, 10);
  ws.on("message", raw => {
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    if (msg.type === "join") {
      const room = String(msg.room || "BD01").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,12) || "BD01";
      const name = String(msg.name || "Player").slice(0,16);
      const p = {id, ws, room, name, x:100+Math.random()*500, y:100+Math.random()*300, hp:100, color:["#36c5f0","#ffcc33","#ff6688","#a78bfa"][Math.floor(Math.random()*4)]};
      players.set(id,p);
      send(ws,{type:"welcome",id,room});
      broadcastRoom(room);
    } else if (msg.type === "move") {
      const p = players.get(id); if (!p) return;
      p.x = Math.max(24,Math.min(776,Number(msg.x)||p.x));
      p.y = Math.max(24,Math.min(476,Number(msg.y)||p.y));
      broadcastRoom(p.room);
    } else if (msg.type === "shoot") {
      const p = players.get(id); if (!p) return;
      const target = players.get(String(msg.target || ""));
      if (target && target.room === p.room && target.id !== p.id) {
        target.hp = Math.max(0, target.hp - 25);
        if (target.hp === 0) {
          target.hp = 100; target.x = 80 + Math.random()*600; target.y = 80 + Math.random()*300;
          p.score = (p.score || 0) + 1;
          send(p.ws,{type:"score",score:p.score});
        }
        broadcastRoom(p.room);
      }
    }
  });
  ws.on("close", () => {
    const p = players.get(id);
    if (p) { const room = p.room; players.delete(id); broadcastRoom(room); }
  });
});
server.listen(PORT, () => console.log(`FIRE BANGLADESH multiplayer running on port ${PORT}`));
